import * as React from "react";

import MenuContainer from './MenuContainer';

class App3 extends React.Component {
    render() {
      return (
        <MenuContainer/>
      )
    }
  }
  
  
  export default App3;
  
  
  