import { CHANGE_VALUES } from './actionTypes';

export const addToDo = () => ({
    type: CHANGE_VALUES
});



export function addTodo() {
    alert("Hello3");
    console.log("hello 3");
    return {
      type: CHANGE_VALUES
    
    }
  }