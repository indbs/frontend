
import React from "react";

const Redux = ({ reduxValues }) => {
  return (
    <div className="hello-world">
      Hello World 123  <span className="hello-world__tech">{reduxValues}!</span>


   

    </div>
  );
};

export default Redux;