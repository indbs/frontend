export default function () {
	return [{
		"name": "Miguel",
		"phone": "123456789",
	},{
		"name": "Peter",
		"phone": "883292300348",
	},{
		"name": "Jessica",
		"phone": "8743847638473",
	},{
		"name": "Michael",
		"phone": "0988765553",
	}];
}